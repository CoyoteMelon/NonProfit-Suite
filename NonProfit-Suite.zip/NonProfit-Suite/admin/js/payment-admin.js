/**
 * Payment Admin JavaScript
 *
 * @package NonprofitSuite
 * @since 1.7.0
 */

(function($) {
	'use strict';

	// Additional JS functionality beyond inline scripts
	// Most functionality is inline in each view template for simplicity

})(jQuery);

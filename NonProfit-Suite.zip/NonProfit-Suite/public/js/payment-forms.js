/**
 * Payment Forms JavaScript
 *
 * @package NonprofitSuite
 * @since 1.7.0
 */

// Most JavaScript is inline in the templates for simplicity
// This file can be expanded with shared functions as needed
